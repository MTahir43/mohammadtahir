function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(255, 0, 0,);
  let size = mouseX
  circle(300, 150, size);

}