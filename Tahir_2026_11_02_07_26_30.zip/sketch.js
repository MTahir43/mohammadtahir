
let shade = "royalblue";
let ping;
let myText = "Hello, i'm Mohammad T Tahir";

function preload() {
  ping = loadSound("ping.mp3");
}

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(240);

  //text
  fill("black");
  textSize(35);
  text(myText, width / 2, height / 2);

  //circle
  fill(shade);
  circle(mouseX, mouseY, 60);
}

function mousePressed() {
  shade = "green";
  myText = "it was nice to meet you";
  ping.play();
}